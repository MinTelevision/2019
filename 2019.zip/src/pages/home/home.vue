<template>
  <div class="home">
    <tabs @activeClick="activeClick" ></tabs>
    <main-home v-if="showTab==0"></main-home>
    <main-home2 v-if="showTab==1"></main-home2>
    <main-home3 v-if="showTab==2"></main-home3>
  </div>
</template>
<script>
import tabs from '@/components/tab/index.vue';
import mainHome from '@/components/main/mainHome.vue';
import mainHome2 from '@/components/main/mainHome2.vue';
import mainHome3 from '@/components/main/mainHome3.vue';
export default {
  components: { tabs , mainHome , mainHome2 , mainHome3},
  name: 'home',
  data () {
    return {
      showTab:0,
    }
  },
  methods:{
    activeClick(e){
      this.showTab = e
    }
  },
  mounted(){

  }
}
</script>
<style lang="less" scoped>

</style>
