<template>
  <div class="mainHome">
    3333
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  mounted(){

  }
}
</script>
<style lang="less" scoped>

</style>
