<template>
  <div class="mainHome">
    <swiper class="swiperList" auto height="100px">
      <swiper-item v-for="(item,index) in swiperList" :key="index" class="black"><h2 class="title fadeInUp animated">{{item}}</h2></swiper-item>
    </swiper>
    <div v-if="Empty" class="marquee">
      <marquee class="marqueeLists">
        <marquee-item v-for="(item,index) in swiperList2" :key="index" class="align-middle">{{item}}</marquee-item>
      </marquee>
      <x-icon @click.native="clickEmpty" class="icons" type="ios-close-empty" size="30"></x-icon>
    </div>
    <card>
      <!-- <img slot="header" src="../../assets/img/2020.jpg" style="width:50%;display:block;"> -->
      <div slot="content" class="card-demo-flex card-demo-content01">
        <div class="vux-1px-r">
          <span>1130</span>
          <br/>
          项目总数
        </div>
        <div class="vux-1px-r">
          <span>15</span>
          <br/>
          独立项目
        </div>
        <div class="vux-1px-r">
          <span>0</span>
          <br/>
          合作项目
        </div>
        <div>
          <span>0</span>
          <br/>
          本月BUG
        </div>
      </div>
      <div slot="content" class="card-padding">
        <p style="color:#999;font-size:12px;">Posted on January 21, 2015</p>
        <p style="font-size:14px;line-height:1.2;">Quisque eget vestibulum nulla. Quisque quis dui quis ex ultricies efficitur vitae non felis. Phasellus quis nibh hendrerit..</p>
      </div>
      <div slot="content" class="card-padding">
        <p style="color:#999;font-size:12px;">Posted on January 21, 2015</p>
        <p style="font-size:14px;line-height:1.2;">Quisque eget vestibulum nulla. Quisque quis dui quis ex ultricies efficitur vitae non felis. Phasellus quis nibh hendrerit..</p>
      </div>
    </card>
    <!-- <card>
      
    </card> -->
  </div>  
</template>
<script>
import { Swiper,SwiperItem,Marquee, MarqueeItem ,Card} from 'vux'
import year from '@/assets/img/2020.jpg'
export default {
  components: {
    Swiper,
    SwiperItem,
    Marquee, 
    MarqueeItem,
    Card
  },
  data () {
    return {
      Empty:true,
      swiperList:['回首过去','激情满怀','展望未来','任重道远','我们试图','做些改变'],
      swiperList2:['看到前进中的困难与挑战','正视自身存在的差距与不足','以更加坚定的信念','更加饱满的热情','更加务实的作风','更加强大的合力','共同谱写公司发展的新篇章','为公司提供强有力的技术支持'],
    }
  },
  methods:{
    clickEmpty(){
      this.Empty = false
    }
  },  
  mounted(){

  }
}
</script>
<style lang="less" scoped>
  .mainHome{
    padding:10/@r;
    .swiperList{
      border-radius: 8/@r;
      margin-bottom:10/@r;
      .black {
        background-color: @c;
      }
      .title{
        line-height: 100/@r;
        text-align: center;
        color: #fff;
      }
      .animated {
        animation-duration: 1s;
        animation-fill-mode: both;
      }
    }
    .marquee{
      position:relative;
      padding:10/@r 0; 
      border-top: 1/@r solid #f5f5f5;
      border-left: none;
      border-right: none;
    }
    .icons{
      padding-right:10/@r;
      text-align: right;
      fill:#ccc;
      position:absolute;
      top:4/@r;
      right:0;
    }
    .align-middle {
      text-align: center;
      color:#555;
    }
  }
  .vux-1px-r{
    border-right:1/@r solid #f5f5f5;
  }
  .card-demo-flex {
    margin: 10/@r 0;
    display: flex;
    >div{
      flex: 1;
      text-align: center;
      font-size: 12/@r;
    }
    span{
       color: @c;
    }
  }
  .card-padding {
    padding: 15/@r;
    border-top:2/@r solid #fbfbfb;
  }
</style>
