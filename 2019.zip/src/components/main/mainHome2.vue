<template>
  <div class="mainHome">
    2222
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  mounted(){

  }
}
</script>
<style lang="less" scoped>

</style>
