<template>
  <div class="top">
    <img :src="logo" alt="">
    <x-icon class="icons" type="ios-heart" size="16"></x-icon>
  </div>
</template>
<script>
import logo from "@/assets/img/logo.png";
import { Icon } from 'vux'
export default {
  components:{Icon},
  data () {
    return {
      logo:logo,
    }
  },
  mounted(){

  }
}
</script>
<style lang="less" scoped>
  .top{
    height: 50/@r;
    text-align: center;
    line-height: 50/@r;
    color:@c;
    border-bottom:1/@r solid #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    img{
      height: 80%;
    }
    .icons{
      padding-top:15/@r;
      transform:rotate(20deg);
    }
  }
</style>
