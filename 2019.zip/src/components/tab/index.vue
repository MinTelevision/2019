<template>
  <div class="tab">
    <tab>
      <tab-item :selected="item.activeIndex" v-for="(item, index) in tabList" :key="index" @on-item-click="activeClick(index)" >{{item.title}}</tab-item>
    </tab>
  </div>
</template>
<script>
import { Tab, TabItem} from 'vux'
export default {
  components:{Tab, TabItem},
  // props:{
  //   active: {
  //     type: Number,
  //     default: 0
  //   },
  // },
  data () {
    return {
      tabList:[{
        title:'工作',
        activeIndex:true,
      },{
        title:'团队',
        activeIndex:false,
      },{
        title:'技术',
        activeIndex:false,
      }],
    }
  },
  methods:{
    activeClick(e){
      this.$emit('activeClick',e)
    }
  },
  mounted(){

  }
}
</script>
<style lang="less" scoped>
  .tab{
    height:44/@r;
  }
</style>
