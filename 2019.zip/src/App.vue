<template>
  <div id="app">
    <tops></tops>
    <router-view/>
  </div>
</template>

<script>
import tops from '@/components/top/index.vue';
export default {
  name: 'App',
  components: { tops },
  // com
}

</script>

<style lang="less">
// @import './assets/css/com.less';
#app {
  height:100%;
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  font-size:16/@r;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
